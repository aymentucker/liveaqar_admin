<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /Users/oman/Downloads/Brander/liveaqar_backend/live/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>