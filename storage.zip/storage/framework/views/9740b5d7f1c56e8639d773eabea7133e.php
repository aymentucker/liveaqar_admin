<?php echo e($slot); ?>

<?php /**PATH /Users/oman/Downloads/Brander/liveaqar_backend/live/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>